#include "test_util.h"
#include <iostream>

bool TestUtil::test(double expected, double actual) {
    if (expected == actual) {
        std::cout << "Test passed: Expected = " << expected << ", Actual = " << actual << std::endl;
        return true;
    } else {
        std::cout << "Test failed: Expected = " << expected << ", Actual = " << actual << std::endl;
        return false;
    }
}
