#include "triangle.h"
#include "triangle.cpp"
#include "test_util.h"

int main() {

  Triangle t1 = Triangle();
  t1.setSides(3, 4, 5);
  
  TestUtil getters;
  getters.test(3, t1.getA()); // check getA()
  getters.test(4, t1.getB()); // check getB()
  getters.test(5, t1.getC()); // check getC()

  TestUtil invariants;
  Triangle t_invariants = Triangle();
  t_invariants.setSides(2, 4, 6);
  t_invariants.setA(0);
  invariants.test(0, 0); // "a <= 0"
  t_invariants.setA(3);
  invariants.test(3, t1.getA()); // "a >= 0"

  Triangle t_circumference = Triangle();
  t_circumference.setSides(4, 4, 4);
  TestUtil circumference;
  circumference.test(12, t_circumference.circumference()); // check circumference()

  Triangle t_area = Triangle(3, 4, 5);
  TestUtil area;
  area.test(6, t_area.area()); // check area()

  return 0;
}
