#pragma once

using namespace std;

class Triangle
{
private:
double _a;
double _b;
double _c;

public:
Triangle();
Triangle(double a, double b, double c);
double getA () const;
void setA (double a);
double getB () const;
void setB (double b);
double getC () const;
void setC (double c);
void setSides(double a, double b, double c);
double circumference();
double area();
void print();
};

