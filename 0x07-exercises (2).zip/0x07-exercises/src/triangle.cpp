#include "triangle.h"
#include "cmath"

using namespace std;

Triangle::Triangle() {}

Triangle::Triangle(double a, double b, double c) : _a(a), _b(b), _c(c) {}

double Triangle::getA() const
{
    return _a;
}

double Triangle::getB() const
{
    return _b;
}

double Triangle::getC() const
{
    return _c;
}

void Triangle::setA(double a)
{
    _a = a;
}
void Triangle::setB(double b)
{
    _b = b;
}
void Triangle::setC(double c)
{
    _c = c;
}

void Triangle::setSides(double a, double b, double c)
{
   _a=a;
   _b=b;
   _c=c;
}

double Triangle::circumference()
{
    return (_a + _b + _c);
}

double Triangle::area()
{
    double s = (_a+_b+_c) /2;
    return sqrt (s*(s-_a)*(s-_b)*(s-_c));
}

void Triangle::print()
{
}