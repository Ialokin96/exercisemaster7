#ifndef TEST_UTIL_H
#define TEST_UTIL_H

class TestUtil {
  public:
    bool test(double expected, double actual); 
};

#endif
